<?php
class WxfcAction extends BackAction{

	public function index(){
	
	}
}