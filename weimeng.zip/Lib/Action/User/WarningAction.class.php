<?php
/**
 * Created by IntelliJ IDEA.
 * User: Topher
 * Date: 14-4-28
 * Time: 下午5:03
 * To change this template use File | Settings | File Templates.
 */
class WarningAction extends BaseAction{




}