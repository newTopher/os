<?php
class UserAction extends BaseAction{
	protected function _initialize(){
		parent::_initialize();
		$userinfo=M('User_group')->where(array('id'=>session('gid')))->find();
		$wecha=M('Wxuser')->field('wxname,wxid,weixin,headerpic')->where(array('token'=>session('token'),'uid'=>session('uid')))->find();
		$this->assign('wecha',$wecha);
		$this->assign('token',session('token'));
		$this->assign('userinfo',$userinfo);
		if(session('uid')==false){
			$this->redirect('Home/Index/login');
		}
        /*if(session('token')==false){
            $this->error('请先绑定您的微信公众账号哦',U('Bind/index'));
        }*/
	}
}