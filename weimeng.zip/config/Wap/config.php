<?php
return array(
	'TMPL_FILE_DEPR'=>'_',
	'DEFAULT_THEME'=>'default',
        'PATHINFO_URL_MODEL'=>2
);