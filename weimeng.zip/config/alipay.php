<?php 
return array (
  'alipay_name' => '318380123@qq.com',
  'alipay_pid' => '2088111963095715',
  'alipay_key' => 'w5two8upy612u2srb8sdfu5vkfjmlxql',
);