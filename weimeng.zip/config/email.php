<?php 
return array (
  'email' => 'false',
  'email_server' => '',
  'email_port' => '',
  'email_user' => '',
  'email_pwd' => '',
  'email_form' => 'aaa',
  'reg_email_title' => '注册成功',
  'reg_email_content' => '尊敬的用户{username}:
       感谢您在{time}注册了WeiKuCMS微分享系统演示站,现在开始验证邮箱!

请将以下网址复制到浏览器进行验证 {code} 进行验证! ^_^

WeiKuCMS微分享系统,分享快乐,快乐每一天!http://www.WeiKuCMS.com',
  'pwd_email_title' => '密码找回',
  'pwd_email_content' => '尊敬的用户{username}:
      这一封是来自远方的信,目的是测试找回您遗失的密码.

请将以下网址复制到浏览器进行验证 {code} 进行验证! ^_^
',
  '__hash__' => '',
);