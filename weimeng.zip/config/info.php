<?php 
return array (
  'site_name' => '万普',
  'site_title' => '万普微信云平台',
  'site_url' => 'http://v.wapwei.com/',
  'site_my' => '万普',
  'ischeckuser' => 'false',
  'ipc' => '皖ICP备14002191号-1',
  'site_qq' => '2892491366',
  'site_qq2' => '1876571451',
  'site_email' => '2892491366@qq.com',
  'site_hm' => '15395427224',
  'baidu_map_api' => '3f79545087f36aa6a72575d57a22baee',
  'keyword' => '万普微信公众平台',
  'content' => '万普微信公众平台',
  'counts' => '&lt;script language=&quot;javascript&quot; type=&quot;text/javascript&quot; src=&quot;http://js.users.51.la/16798134.js&quot;&gt;&lt;/script&gt;
&lt;noscript&gt;&lt;a href=&quot;http://www.51.la/?16798134&quot; target=&quot;_blank&quot;&gt;&lt;img alt=&quot;&amp;#x6211;&amp;#x8981;&amp;#x5566;&amp;#x514D;&amp;#x8D39;&amp;#x7EDF;&amp;#x8BA1;&quot; src=&quot;http://img.users.51.la/16798134.asp&quot; style=&quot;border:none&quot; /&gt;&lt;/a&gt;&lt;/noscript&gt;',
  'copyright' => '万普微盟',
);