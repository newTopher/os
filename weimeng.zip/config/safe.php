<?php 
return array (
  'TOKEN_ON' => 'false',
  'TOKEN_NAME' => '__hash__',
  'TOKEN_TYPE' => 'md5',
  'TOKEN_RESET' => 'false',
  'DB_FIELDTYPE_CHECK' => 'false',
  'VAR_FILTERS' => 'htmlspecialchars',
);