<?php 
return array (
  'up_size' => '2048',
  'up_exts' => 'jpeg,jpg,png',
  'up_path' => './data/upload',
  'connectnum' => '系统维护中',
);