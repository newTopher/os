<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>后台首页</title>
<link href="<?php echo RES;?>/images/main.css" type="text/css" rel="stylesheet">
<meta http-equiv="x-ua-compatible" content="ie=7" />
</head>
<body style="background:none">
<div class="content">
<div class="box">
	<h3>更新消息</h3>
    <div class="con dcon">
    <div class="update">
    <p>服务器环境：Apache/2.2.9 (APMServ) mod_ssl/2.2.9 OpenSSL/0.9.8h PHP/5.2.6</p>
    <p>服务器IP：127.0.0.1</p>
    <p>当前网站语言：UTF-8简体中文</p>
    <p>集团网站：<a href="#" class="blue">公司网站</a></p>
    <p>系统版本：微酷cms W_5_0_201306260001_UTF8 <a href="javascript:alert('暂无升级')" class="isub">检查更新</a></p>
    </div>
    <ul class="myinfo">
   <li><p class="red">您的程序版本为：微酷cms多用户微信营销系统v1.0</p><span>[ 授权版本：商业版 (终身使用权) ]</span></li>
   <li><p class="red">您的程序版本为：微酷cms多用户微信营销系统v1.0</p><span>[ 授权版本：商业版 (终身免费) ]</span></li>
  
	</ul>
    </div>
</div>
<!--/box-->
<div class="box">
	<h3>微酷cms官方动态</h3>
    <div class="con dcon">
    <div class="kjnav">
    <a href="http://www.weikucms.com">使用帮助</a><a href="http://www.weikucms.com">技术售后</a><a href="http://www.weikucms.com">安装指导</a><a href="http://www.weikucms.com">联系我们</a><a href="http://wwwweikucms.com">升级咨询</a>
    </div>
    <ul class="myinfo kjinfo">
   <li class="title">售后服务范围</li>
<li>程序第一次安装指导,或第一次协助安装</li>
<li>服务时间：早9:00 晚10:00 如有疑问请在这个时间段联系我们，周未双休</li>
<li>个人版，请勿修改程序,您的擅自修改出现的任何问题,将不在售后内('可指导')</li>
<li>如果有BUG,微酷cms承诺1至3天内发布修复补丁</li>
<li>如果您购买的是全功能版,微酷cms开发出新的模块功能,您会在第一时间得到升级包</li>
	</ul>
    </div>
</div>

<!--/box-->
</div>
</body>
</html>