<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
<title>注册－<?php echo C('site_title');?></title>
<meta name="keywords" content="weikucms 微信帮手 微信公众账号 微信公众平台 微信公众账号开发 微信二次开发 微信接口开发 微信托管服务 微信营销 微信公众平台接口开发"/>
<meta name="description" content="微信公众平台接口开发、托管、营销活动、二次开发"/>
    <script src="<?php echo RES;?>/js/html5.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/bootstrap.css" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/reg.css" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/style.css" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/index.css" media="all" />
<script type="text/javascript" src="<?php echo RES;?>/js/jQuery.js"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/omvalidate.js"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/placeholder.js"></script>
<script type="text/javascript" src="<?php echo RES;?>/js/index.js"></script>
<link rel="shortcut icon" href="favicon.ico" />
</head>
<body>



<link href="<?php echo RES;?>/kf/css/style.css" rel="stylesheet" type="text/css" />


<!-- 代码 开始 -->
<div class="qust_contach"> <a href="javascript:void(0);" class="qst_close icon">&nbsp;</a> <br class="clear">
  <ul>
    <li style="border-top:none">
      <p><span class="icon zixun"></span>在线咨询</p>
      <b>工作日：</br>9:00-17:00</b> <a target="_blank" href="http://wpa.qq.com/msgrd?V=1&amp;Uin=1876571451&Site=微酷CMS&Menu=yes"><img border="0" src="<?php echo RES;?>/kf/images/group.png" alt="联系我们" title="联系我们"></a> </li>
    <li>
      <p><span class="icon yuyue"></span>预约技术</p>
      <b>一对一解决方案</b> <a target="_blank" href="http://wpa.qq.com/msgrd?V=1&amp;Uin=2892491366&Site=微酷CMS&Menu=yes"><img border="0" src="<?php echo RES;?>/kf/images/group.png" alt="预约技术" title="预约技术"></a> </li>
    <li>
      <p><span class="icon tijian"></span>免费试用体验</p>
      <b>&nbsp;立即进入体验中心</b> <a href="http://www.weikucms.com/index.php?m=Index&a=reg" target="_blank"  title="免费网站体检" class="icon tj_btn">我要体验</a> </li>
   <!-- <li>
      <p><span class="icon suces"></span>成功案例</p>
      <div class="suces_btn" style="margin-top: 2px;"> <a href="http://www.weikucms.com/index.php?m=Index&a=reg" target="_blank" title="建站案例" class="icon">建站案例</a> <a href="http://www.weikucms.com/index.php?m=Index&a=reg" target="_blank" title="推广案例" class="icon" style="margin-left: 3px;">推广案例</a> <br class="clear"/>
      </div>
    </li>-->

    <li >
      <p><span class="icon shouqian"></span>售前咨询</p>
      <b><a target="_blank" href="http://wpa.qq.com/msgrd?V=1&amp;Uin=1876571451&Site=微酷CMS&Menu=yes"><img border="0" src="<?php echo RES;?>/kf/images/group.png" alt="售前咨询" title="售前咨询"></a></b>
<b><a target="_blank" href="http://wpa.qq.com/msgrd?V=1&amp;Uin=2892491366&Site=微酷CMS&Menu=yes"><img border="0" src="<?php echo RES;?>/kf/images/group.png" alt="售前咨询" title="售前咨询"></a></b> 
</li>
    <li>
      <p><span class="icon shouhou"></span>售后咨询</p>
      <b><a target="_blank" href="http://wpa.qq.com/msgrd?V=1&amp;Uin=2892491366&Site=微酷CMS&Menu=yes"><img border="0" src="<?php echo RES;?>/kf/images/group.png" alt="售后咨询" title="售后咨询"></a></b> </li>
    <li id ="toTop" style="border-bottom:none; height:0px;overflow: hidden;cursor: pointer;"> <a href="javascript:void(0);" class="back_top icon">&nbsp;</a> </li>
  </ul>
</div>
<div class="qust_show" style="display:none;"> <a href="javascript:void(0);"> <span class="icon server"></span><br/>
  <span>在</span><br/>
  <span>线</span><br/>
  <span>咨</span><br/>
  <span>询</span><br/>
  </a> </div>

<script type="text/javascript" src="<?php echo RES;?>/kf/js/contact.js"></script>
<div style="text-align:center;clear:both">
</div>
<!-- 代码 结束 -->



	 <!--[if lte IE 8]>  <script language="javascript">$(function (){$.browser.msie&&$("#ie9-tips").show().find("#stopSuggestA").click(function(){$("#ie9-tips").hide()})})</script><![endif]-->
<div class="nav clearfix">
	<div class="nav-content">
		<h1 class="left"><a href="/">WeiKuCMS·微信营销，如此简单！</a></h1>
		<div class="right line-li">
			<ul>
				<li>
					<a href="/">首页</a>
				</li>
				<li>
				<a href="<?php echo U('Home/Index/guide');?>">功能介绍</a>
				</li>
                <li>
				<a href="<?php echo U('Home/Index/about');?>">关于我们</a>
				</li>
                <li>
				<a href="<?php echo U('Home/Index/quanjing');?>">全景展示</a>
				</li>
				<li>
					<a href="<?php echo U('Home/Index/price');?>" >服务价格</a>
				</li>
				<li>
					<a href="<?php echo U('Home/Index/help');?>" >帮助中心</a>
				</li>
				<?php if($_SESSION[uid]==false): ?><li><a href="javascript:;" class="hover navtwo" onClick="loginBox.toggle(this, event);">登录</a>&nbsp;&nbsp;|&nbsp;&nbsp;</li>
			<li><a href="<?php echo U('Index/reg');?>">注册</a></li>
			<?php else: ?>
			<li><a href="<?php echo U('User/Index/index');?>" hidefocus="true"  ><span style="color:#009;"><?php echo (session('uname')); ?></span></a></li>
			<li>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="/#" onClick="Javascript:window.open('<?php echo U('Admin/Admin/logout');?>','_blank')" >退出</a></li><?php endif; ?>
			</ul>
		</div>
	</div>
</div>
<div id="loginBox">
		<div class="login-panel">
			<h3>登录</h3>
			<div class="login-mod">
				<div class="login-err-panel dn" id="err_area">
					<span class="icon-wrapper"><i class="icon24-login err" style="margin-top:-.2em;*margin-top:0;"></i></span>
					<span id="err_tips"></span>
				</div>
				<form action="<?php echo U('Users/checklogin');?>" method="post" class="login-form">
					<div class="login-un">
						<span class="icon-wrapper"><i class="icon24-login un"></i></span>
						<input type="text" id="username" name="username" tabindex="1" class="ipt tipinput1" placeholder="用户名" autocomplete="off" maxlength="100" suggestwidth="374px" />
					</div>
					<div class="login-pwd">
						<span class="icon-wrapper"><i class="icon24-login pwd"></i></span>
						<input type="password" id="password" name="password" tabindex="2" class="ipt tipinput1" placeholder="请输入您的密码" maxlength="20" autocomplete="off" />
					</div>
					<div class="login-btn-panel">
					<input class="login-btn" type="submit"  id="login_button" value="登录"> <a class="login-forget-pwd" href="<?php echo U('Index/reg');?>">我是新用户!<strong>申请入驻</strong></a>
				</div>
				</form>
			</div>
		</div>
		<div class="login-cover" onClick="loginBox.toggle(this, event);">
        </div>
		</div>
	
<div id="ie9-tips" class="clearfix">
	<div id="tipsPanel">
		<div id="tipsDesc">系统检测到您所使用的浏览器版本较低，推荐使用<a href="http://www.firefox.com.cn/download/" target="_blank">Firefox</a>或<a href="http://www.google.cn/intl/zh-CN/chrome/browser/index.html" target="_blank">Chrome</a>浏览器打开，否则将无法体验完整产品功能。</div>
		<a id="stopSuggestA" href="javascript:;">×</a>
	</div>
</div>
<div class="Public-content clearfix">
	<div class="Public">
		<h1 class="Public-h1">注册</h1>
		<div class="Public-box clearfix">
			<div class="reg-wrapper2">
            <form action="<?php echo U('Users/checkreg');?>" method="post" class="form-horizontal">
                <div class="control-group">
						<label class="control-label" for="username">用户名</label>
						<div class="controls" >
							<input class="text" required="" value="请输入用户名" onclick="if(this.value=='请输入用户名'){this.value=''}" onblur="if(this.value==''){this.value='请输入用户名'}" type="text" name="username">
							<span class="maroon">*</span><span class="help-inline" style=" color:#c35d00;">长度为6~16位字符，可以为“数字/字母/中划线/下划线”组成</span>
						</div>
					</div>
                    <div class="control-group">
						<label class="control-label" for="password">设置密码</label>
						<div class="controls">
							<input class="text" type="password" name="password">
							<span class="maroon">*</span><span class="help-inline" style=" color:#c35d00;">长度为6~16位字符</span>
						</div>
					</div>
					 <div class="control-group">
						<label class="control-label" for="repassword">确认密码</label>
						<div class="controls">
							<input class="text" type="password" name="repassword">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="phone">手机</label>
						<div class="controls">
							<input type="text" name="phone" id="phone" onClick="javascript:_gaq.push(['_trackPageview','/home/reg/virtual/Phone']);">
							<span class="maroon">*</span><span class="help-inline" style=" color:#c35d00;">请输入正确的手机号码</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="email">邮箱</label>
						<div class="controls">
							<input class="text" type="text" name="email" value="请输入电子邮箱" onclick="if(this.value=='请输入电子邮箱'){this.value=''}" onblur="if(this.value==''){this.value='请输入电子邮箱'}">
							<span class="maroon">*</span><span class="help-inline" style=" color:#c35d00;">邮箱将与支付及优惠相关，请填写正确的邮箱</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="qq">QQ</label>
						<div class="controls">
							<input type="text" name="qq" id="qq" onClick="javascript:_gaq.push(['_trackPageview','/home/reg/virtual/QQ']);">
						</div>
					</div>
                   <div class="control-group">
						<div class="controls">
							<button type="submit" id="reg-btn" class="btn-register" style="display:none;"></button>
							<button type="submit" class="btn-register" onClick="validityInvitecode(this); return false;javascript:_gaq.push(['_trackPageview','/home/reg/virtual/Submit']);"></button>
						
					</div>
                    <div  style=" color:#ffffff; text-align:center" >帐号审核请联系网站客服！</div></div>
            </form>
			</div>
		</div>
	</div>
</div>
﻿<div class="erwei" title="微信扫一扫">
	<span class="hudongzhushou">官方微信</span>
	<div class="erwei_big" style="display:none;">
		<p>扫一扫，关注WeiKuCMS官方微信，体验WeiKuCMS智能服务</p>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		var erwei_time = null;
		$(".erwei").hover(function(){
			$(".erwei_big").show();
		}).mouseleave(function(){
				erwei_time = setTimeout(function(){
					$(".erwei_big").hide();
				},1000);
			});
		$(".erwei_big").mouseenter(function(){
			if(erwei_time){
				clearTimeout(erwei_time);
			}
		}).mouseleave(function(){
				erwei_time = setTimeout(function(){
					$(".erwei_big").hide();
				},1000);
			});
	});
</script>
<div class="footer">
	<div class="footer-content clearfix">
		<div class="foot-menu">
			
			<p>服务QQ：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo C('site_qq');?>&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:<?php echo C('site_qq');?>:51" alt="联系我吧" title="联系我吧"/></a>&nbsp;&nbsp;&nbsp;QQ1：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo C('site_qq2');?>&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:<?php echo C('site_qq2');?>:51" alt="联系我吧" title="联系我吧"/></a>&nbsp;&nbsp;&nbsp;邮箱：<?php echo C('site_email');?></p>
			<p>服务电话：<?php echo C('site_hm');?>|<?php echo htmlspecialchars_decode(C('counts'));?></p>
		</div>
		<div class="copyright_index" align="center">
		Copyright © 2013-2014. All Rights Reserved <?php echo C('copyright');?>  <?php echo C('ipc');?>
		</div>
        		<!--<div class="copyright" ><a href="##">微酷cms</a></div>-->
	</div>
</div>
<script>
	function feedbackSubmit(){
		var $data = {
			feedback: $('#feedback-text').val(),
			email: $('#feedback-input').val(),
			url: self.location.href
		};
		$.post('/site/feedback', $data, function(rs){
			alert(rs.error);
			if (200 == rs.code)
			{
				$('#feedback, #feedback_cover').toggleClass('on');
			}
		}, 'json');
	}
</script>
<!--公告信息-->
	<div id="notice_mask"></div>
	<div id="notice_message" style="position: absolute; left: 373.5px; top: 20%;">
		<div class="title">公 告<a onClick="javascript:jQuery('#notice_mask').hide(),jQuery('#notice_message').hide();">×</a></div>
		<div class="content">
			<pre style="white-space:pre-wrap;"><p>
	尊敬的WeiKuCMS 微酷CMS 用户、合作伙伴：
</p>
<p>
	WeiKuCMS最新升级：
1.新增微汽车，微房产，微门店，微花店，微物业，微医院，微装修，微婚庆等行业应用，全新的行业板块让您的企业运营更加高端！
2.微商城团购订餐支持手机在线支付，并支持短信邮件接口，手机支付商城不再是难题！
3.新增分类首页连级菜单，让您的微网站选择活动时不再到处找活动链接！
4.新增了砸金蛋活动，让您的企业活动更加的丰富多彩！
5.修复了会员卡最新通知跳转会员特权的问题，修复了会员卡iOS，android显示不一样的问题！
6.新增了自定义商家LBS功能，附近或者自定义公司信息均可获取！让您的企业无处不在！
7.修复回复慢或者不回复问题！

请认准WeiKuCM官方唯一认定网站：www.weikucms.com

更新时间：2014年3月10日
</p></pre>
		</div>
	</div>

<script type="text/javascript">
	$(document).ready(function(){
		$('#notice_mask').click(function(){
			$('#notice_mask').hide();
			$('#notice_qrcode').hide();
			$('#notice_message').hide();
		});

		$(window).resize(function(){
			$('#notice_qrcode').css({
				position:'absolute',
				left: ($(window).width() - $('#notice_qrcode').outerWidth())/2,
				top: ($(window).height() - $('#notice_qrcode').outerHeight())/2
			});

			$('#notice_message').css({
				position:'absolute',
				left: ($(window).width() - $('#notice_message').outerWidth())/2,
				top: ($(window).height() - $('#notice_message').outerHeight())/2
			});
		});
	});
</script>

<!-- Baidu Button BEGIN -->
<script type="text/javascript" id="bdshare_js" data="type=slide&amp;img=5&amp;pos=left&amp;uid=6461542" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000);
</script>
<!-- Baidu Button END -->
</body>
</html>