<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
    
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <!-- Apple devices fullscreen -->
        <meta name="apple-mobile-web-app-capable" content="yes">
        <!-- Apple devices fullscreen -->
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
        <link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/wapwei/index.css"
        media="all">
        <link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/wapwei/bootstrap_min.css"
        media="all">
        <link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/wapwei/bootstrap_responsive_min.css"
        media="all">
        <link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/wapwei/style.css" media="all">
        <link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/wapwei/themes.css">
        <link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/style.css">
        <link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/wapwei/resource.css">
        <script src="<?php echo RES;?>/js/date/WdatePicker.js"></script>
        <script type="text/javascript" src="<?php echo RES;?>/js/wapwei/jQuery.js">
        </script>
        <script type="text/javascript" src="<?php echo RES;?>/js/wapwei/application.js">
        </script>
        <script type="text/javascript" src="<?php echo RES;?>/js/wapwei/bootstrap_min.js">

        </script>
        <script type="text/javascript" src="<?php echo RES;?>/js/wapwei/notifIt.js"></script>
        <link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/themes/default/default.css" />
        <link rel="stylesheet" href="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.css" />
        <script src="<?php echo STATICS;?>/kindeditor/kindeditor.js" type="text/javascript"></script>
        <script src="<?php echo STATICS;?>/kindeditor/lang/zh_CN.js" type="text/javascript"></script>
        <script src="<?php echo STATICS;?>/kindeditor/plugins/code/prettify.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo RES;?>/css/wapwei/notifIt.css" media="all">
        <style type="text/css">
            .dropdown-submenu:hover>.dropdown-menu{display:none}
        </style>
        <title>
            <?php echo C('site_title');?> <?php echo C('site_name');?>
        </title>
        <!--[if IE 7]>
            <link href="http://stc.weimob.com/css/font_awesome_ie7.css" rel="stylesheet"
            />
        <![endif]-->
        <!--[if lte IE 8]>
            <script language="javascript" type="text/javascript" src="http://stc.weimob.com/src/excanvas_min.js">
            </script>
        <![endif]-->
        <script>
            var SITEURL = '';
        </script>
    </head>
    
    <body>
        <div id="navigation">
            <div class="container-fluid">
                <div>
                    <a href="" target="_self" id="brand">
                        <img src="<?php echo RES;?>/images/logo_wapwei.png" style="width: 100px;">
                    </a>

                </div>

                <div class="user">
                    <ul class="icon-nav">

                        <li class="dropdown sett" style="display:none;">
                            <a href="http://www.weimob.com/wechat/index/aid/116261#" class="dropdown-toggle"
                            data-toggle="dropdown" title="系统设置">
                                <i class="icon-cog">
                                </i>
                            </a>
                        </li>

                            </ul>
                        </li>
                    </ul>
                    <div class="dropdown">
                        <a href="http://www.weimob.com/wechat/index/aid/116261#" class="dropdown-toggle"
                        data-toggle="dropdown" style="width:127px;">
                            <nobr>
                                <?php echo (session('uname')); ?>
                                <img src="./微盟（Weimob）—国内最大的微信公众服务平台_files/a398c0d3c9c87d989b8285c517c796b9.jpg"
                                style="width: 27px; height: 27px" alt="">
                                <span class="caret">
                                </span>
                            </nobr>
                        </a>
                        <ul class="dropdown-menu pull-right" style="min-width: 147px;">
                            <li>
                                <a href="<?php echo U('Admin/Admin/logout');?>" target="_self">
                                    退出
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid" id="content">
            <div id="left" style="overflow: hidden; outline: none;" tabindex="5000">
                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-down">
                            </i>
                            <span>
                                我的万普微盟
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Home') OR (MODULE_NAME == 'Bind') OR (MODULE_NAME == 'Index')): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>
                        <li <?php if(MODULE_NAME == 'Home'): ?>class="selected" <?php else: ?> class="subCatalogList"<?php endif; ?>>
                            <a href="<?php echo U('Home/index',array('token'=>$token,'id'=>session('wxid')));?>">
                                我的首页
                            </a>
                        </li>
                        <li <?php if(MODULE_NAME == 'Bind'): ?>class="selected" <?php else: ?> class="subCatalogList"<?php endif; ?>>
                            <a href="<?php echo U('Bind/index',array('token'=>$token,'id'=>session('wxid')));?>">
                                账号绑定
                            </a>
                        </li>
                        <li <?php if(MODULE_NAME == 'Index'): ?>class="selected" <?php else: ?> class="subCatalogList"<?php endif; ?>>
                            <a href="<?php echo U('Index/edit',array('token'=>$token,'id'=>session('wxid')));?>">
                                个人设置
                            </a>
                        </li>
                        <li <?php if(MODULE_NAME == 'Sms'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>>
                        <a href="<?php echo U('Index/editsms',array('id'=>session('wxid')));?>">短信平台配置<span class="new"></span></a>
                        </li>
                        <li <?php if(MODULE_NAME == 'Email'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>>
                        <a href="<?php echo U('Index/editemail',array('token'=>$token));?>">邮件平台配置<span class="new"></span></a>
                        </li>
                       <li   <?php if(MODULE_NAME == 'Alipay_config'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Alipay_config/index',array('token'=>$token));?>">支付设置</a></li>
                        <li <?php if(MODULE_NAME == 'Index'): ?>class="selected" <?php else: ?> class="subCatalogList"<?php endif; ?>>
                            <a href="<?php echo U('Index/useredit',array('token'=>$token,'id'=>session('wxid')));?>">
                                修改密码
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-right">
                            </i>
                            <span>
                               微信基础服务
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Function') OR (MODULE_NAME == 'Fang') OR (MODULE_NAME == 'Areply') OR (MODULE_NAME == 'Text') OR (MODULE_NAME == 'Img') OR (MODULE_NAME == 'Voiceresponse') OR (MODULE_NAME == 'lbslist') OR (MODULE_NAME == 'Index')): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>


                        <li <?php if(MODULE_NAME == 'Areply'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Areply/index',array('token'=>$token));?>">首次关注</a>
                        </li>
                        <li <?php if(MODULE_NAME == 'Text'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Text/index',array('token'=>$token));?>">文本回复</a>
                        </li>
                        <li <?php if(MODULE_NAME == 'Img'): ?>class="selected" <?php else: ?> class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Img/index',array('token'=>$token));?>">图文回复</a>
                        </li>
                        <li   <?php if(MODULE_NAME == 'Voiceresponse'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Voiceresponse/index',array('token'=>$token));?>">语音回复</a>
                        </li>
                        <li   <?php if(MODULE_NAME == 'lbslist'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="javascript:alert('已经实现智能地理位置回复，无需人工设置')">LBS回复</a><span class="new"></span>
                        </li>
                        <li   <?php if(MODULE_NAME == 'Diymen'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Diymen/index',array('token'=>$token));?>">微信自定义菜单<span class="new"></span></a>
                        </li>

                    </ul>
                </div>

                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-down">
                            </i>
                            <span>
                                我的微信粉丝
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" style="display: block;">
                        <li>
                            <a href="http://www.weimob.com/wechat/home?aid=116261">
                                微信粉丝
                            </a>
                        </li>
                        <li>
                            <a href="http://www.weimob.com/wechat/home?aid=116261">
                                粉丝消息
                            </a>
                        </li>
                        <li>
                            <a href="http://www.weimob.com/wechat/home?aid=116261">
                                粉丝分组
                            </a>
                        </li>
                    </ul>
                </div>
                
                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-right">
                            </i>
                            <span>
                                微官网设置
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Home') OR (MODULE_NAME == 'Classify') OR (MODULE_NAME == 'Tmpls') OR (MODULE_NAME == 'Flash') OR (MODULE_NAME == 'Yulan') OR (MODULE_NAME == 'speeddial') OR (MODULE_NAME == 'Diymen')): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>
                        <li <?php if(MODULE_NAME == 'Home'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Home/set',array('token'=>$token));?>">首页回复配置</a>
                        </li>
                        <li <?php if(MODULE_NAME == 'Classify'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Classify/index',array('token'=>$token));?>">分类管理</a>
                        </li>
                        <li   <?php if(MODULE_NAME == 'Tmpls'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Tmpls/index',array('token'=>$token));?>">模板管理</a>
                        </li>
                        <li   <?php if(MODULE_NAME == 'Flash'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Flash/index',array('token'=>$token));?>">首页轮播图<span class="new"></span></a>
                        </li>
                        <li <?php if(MODULE_NAME == 'Yulan'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>>
                        <a  href="<?php echo U('Yulan/index',array('token'=>$token));?>">微网站预览<span class="new"></span></a>
                        </li>
                        <li   <?php if(MODULE_NAME == 'speeddial'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('speeddial/index',array('token'=>$token));?>">导航版权音乐<span class="new"></span></a>
                        </li>

                    </ul>
                </div>

                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-right">
                            </i>
                            <span>
                                微电商
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Groupon') OR (MODULE_NAME == 'Company') OR (MODULE_NAME == 'Product') OR (MODULE_NAME == 'orders') OR (MODULE_NAME == 'Qj') OR (MODULE_NAME == 'Panorama') OR (MODULE_NAME == 'Discount_input')): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>
                        <li <?php if((MODULE_NAME == 'Groupon') and (ACTION_NAME == 'index')): ?>class="selected"<?php else: ?>class="subCatalogList"<?php endif; ?> >

                    <a href="<?php echo U('Groupon/index',array('token'=>$token));?>">微信团购系统</a><span class="new"></span>
                    </li>
                    <li <?php if((MODULE_NAME == 'Company') and (ACTION_NAME == 'index')): ?>class="selected"<?php else: ?>class="subCatalogList"<?php endif; ?>>
                    <a href="<?php echo U('Company/index',array('token'=>$token));?>">商家信息</a><span class="new"></span>
                    </li>
                    <li <?php if((MODULE_NAME == 'Product') and (ACTION_NAME == 'index')): ?>class="selected"<?php else: ?>class="subCatalogList"<?php endif; ?> >
                    <a href="<?php echo U('Product/index',array('token'=>$token));?>">微信商城系统</a><span class="new"></span>
                    </li> 
                    <li <?php if(ACTION_NAME == 'orders'): ?>class="selected"<?php else: ?>class="subCatalogList"<?php endif; ?> >
                    <a href="<?php echo U('Product/orders',array('token'=>$token,'dining'=>1));?>">微信订餐</a><span class="new"></span>
                    </li>

                    <li <?php if(MODULE_NAME == 'Xt'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Discount_input/index',array('token'=>$token));?>">二维码扫码折扣</a>
                    </li>
                    </ul>
                </div>
                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-right">
                            </i>
                            <span>
                                微应用
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Xt') OR (MODULE_NAME == 'Car_pp') OR (MODULE_NAME == 'Estate') OR (MODULE_NAME == 'Medical') OR (MODULE_NAME == 'Reservation') OR (MODULE_NAME == 'Shipin') OR (MODULE_NAME == 'Jianshen') OR (MODULE_NAME == 'Zhengwu') OR (MODULE_NAME == 'Lvyou') OR (MODULE_NAME == 'Jiaoyu') OR (MODULE_NAME == 'Huadian') OR (MODULE_NAME == 'Wuye') OR (MODULE_NAME == 'Ktv') OR (MODULE_NAME == 'Jiuba') OR (MODULE_NAME == 'Zhuangxiu') OR (MODULE_NAME == 'Hunqing') OR (MODULE_NAME == 'Host')): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>
                        <li <?php if(MODULE_NAME == 'Xt'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Xt/index',array('token'=>$token));?>">微喜贴</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Car'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Car_pp/index',array('token'=>$token));?>">微汽车</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Estate'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Estate/index',array('token'=>$token));?>">微房产</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Medical'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Medical/index',array('token'=>$token));?>">微医疗</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Reservation'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Reservation/index',array('token'=>$token));?>">微美容</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Shipin'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Shipin/index',array('token'=>$token));?>">微食品</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Jianshen'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Jianshen/index',array('token'=>$token));?>">微健身</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Zhengwu'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Zhengwu/index',array('token'=>$token));?>">微政务</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Lvyou'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Lvyou/index',array('token'=>$token));?>">微旅游</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Jiaoyu'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Jiaoyu/index',array('token'=>$token));?>">微教育</a>
                      </li>
                      <li <?php if(MODULE_NAME == 'Huadian'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Huadian/index',array('token'=>$token));?>">微花店</a>
                      </li>
                      <li   <?php if(MODULE_NAME == 'Host'): ?>class="selected"<?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Host/index',array('token'=>$token));?>">通用订单(酒店,KTV)</a></li>

                    <li   <?php if(MODULE_NAME == 'Adma'): ?>class="selected"<?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Adma/index',array('token'=>$token));?>">微宣传</a><span class="new"></span></li>
                    <li   <?php if(MODULE_NAME == 'Photo'): ?>class="selected"<?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Photo/index',array('token'=>$token));?>">微相册</a><span class="new"></span></li>

                    <li   <?php if(MODULE_NAME == 'Selfform'): ?>class="selected"<?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Selfform/index',array('token'=>$token));?>">微表单</a><span class="new"></span></li>
                    <li <?php if(MODULE_NAME == 'Liuyan'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Liuyan/index',array('token'=>$token));?>">微留言</a>
                    </li>
                    <li <?php if(MODULE_NAME == 'Vote'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Vote/index',array('token'=>$token));?>">微投票</a>
                    </li>
                    <li   <?php if(MODULE_NAME == 'Wxq'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Wxq/index',array('token'=>$token));?>">微信墙<span class="new"></span></a></li>
                    <li   <?php if(MODULE_NAME == 'Gcard'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Gcard/index',array('token'=>$token));?>">微贺卡<span class="new"></span></a></li>
                    <li <?php if(MODULE_NAME == 'Qj'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Qj/index',array('token'=>$token));?>">360全景接口版</a>
                    </li>
                    <li   <?php if(MODULE_NAME == 'Panorama'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Panorama/index',array('token'=>$token));?>">360全景手动版<span class="new"></span></a>
                    </li>
                    </ul>
                </div>
                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-right">
                            </i>
                            <span>
                                微活动
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Lottery') OR (MODULE_NAME == 'Coupon') OR (MODULE_NAME == 'Guajiang') OR (MODULE_NAME == 'Zadan') ): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>
                        <li   <?php if(MODULE_NAME == 'Lottery'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Lottery/index',array('token'=>$token));?>">幸运大转盘</a><span class="new"></span></li>
                        <li   <?php if(MODULE_NAME == 'Coupon'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Coupon/index',array('token'=>$token));?>">优惠券</a></li>
                        <li   <?php if(MODULE_NAME == 'Guajiang'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Guajiang/index',array('token'=>$token));?>">刮刮卡</a></li>
                            <li   <?php if(MODULE_NAME == 'Zadan'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Zadan/index',array('token'=>$token));?>">砸金蛋</a></li>
                            <li   <?php if(MODULE_NAME == 'Zadan'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Diaoyan/index',array('token'=>$token));?>">微调研</a></li>
                            <li   <?php if(MODULE_NAME == 'Zadan'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Shake/index',array('token'=>$token));?>">摇一摇</a></li>
                    </ul>
                </div>
                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-right">
                            </i>
                            <span>
                                微信会员卡
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Member_card') OR (MODULE_NAME == 'Member')): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>
                        <li <?php if((MODULE_NAME == 'Member_card') and (ACTION_NAME == 'index')): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Member_card/index',array('token'=>$token));?>">会员卡设计</a></li>
                        <li  <?php if(ACTION_NAME == 'news'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Member_card/news',array('token'=>$token));?>">最新通知</a></li>
                        <li <?php if(ACTION_NAME == 'privilege'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Member_card/privilege',array('token'=>$token));?>">会员特权</a></li>
                        <li <?php if(ACTION_NAME == 'info'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Member_card/info',array('token'=>$token));?>">会员卡详情</a></li>
                        <li <?php if(ACTION_NAME == 'create'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Member_card/create',array('token'=>$token));?>">在线开卡(自定义卡号)</a></li>
                        <li  <?php if(ACTION_NAME == 'exchange'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Member_card/exchange',array('token'=>$token));?>">积分设置</a></li>
                          <li   <?php if(MODULE_NAME == 'Member'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?>> <a href="<?php echo U('Member/index',array('token'=>$token));?>" >会员资料管理</a><span class="new"></span></li>
                    </ul>
                </div>
                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-right">
                            </i>
                            <span>
                                数据魔方
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Requery') OR (MODULE_NAME == 'Member')): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>
                        <li   <?php if(MODULE_NAME == 'Requery'): ?>class="selected" <?php else: ?>class="subCatalogList"<?php endif; ?> > <a href="<?php echo U('Requery/index',array('token'=>$token));?>" >请求数详情</a>
                        </li>
                    </ul>
                </div>

                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-right">
                            </i>
                            <span>
                                微信客服
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Requery') OR (MODULE_NAME == 'Member')): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>
                    <li>
                        <a href="http://www.weimob.com/wechat/home?aid=116261">
                            添加个人微信客服
                        </a>
                    </li>
                    <li>
                        <a href="http://www.weimob.com/wechat/home?aid=116261">
                            微信客服管理
                        </a>
                    </li>

                    </ul>
                </div>

                <div class="subnav">
                    <div class="subnav-title">
                        <a href="javascript:void(0);" class="toggle-subnav">
                            <i class="icon-angle-right">
                            </i>
                            <span>
                                微信独立商城
                            </span>
                        </a>
                    </div>
                    <ul class="subnav-menu" <?php if((MODULE_NAME == 'Requery') OR (MODULE_NAME == 'Member')): ?>style="display:block;" <?php else: ?>style="display:none;"<?php endif; ?>>
                    <li>
                        <a href="http://www.weimob.com/wechat/home?aid=116261">
                            我的微商城
                        </a>
                    </li>

                    </ul>
                </div>
            </div> 
<script src="<?php echo RES;?>/js/date/WdatePicker.js"></script>
 <form class="form" method="post" action=""  target="_top" enctype="multipart/form-data" >
<div class="content"  >
<!--活动开始-->
<div class="cLineB">
    <h4>编辑砸金蛋活动开始内容</h4>

</div> 
<div class="msgWrap bgfc"> 
<TABLE class="userinfoArea" style=" margin:0;" border="0" cellSpacing="0" cellPadding="0" width="100%"><TBODY>
<TR>
  <th valign="top"><span class="red">*</span>关键词：</th>
  <TD>
	<input type="input" class="px" id="keyword" value="<?php if($vo['keyword'] == ''): ?>砸金蛋<?php else: echo ($vo["keyword"]); endif; ?>" name="keyword" style="width:400px" ><br />
  	<span class="red">只能写一个关键词</span>，用户输入此关键词将会触发此活动。
  </TD>
  <TD rowspan="7" valign="top">
	  <div style="margin-left:20px">
		<img id="pic" src="<?php if($vo['starpicurl'] == ''): echo RES;?>/images/img/zajindanstart1.jpg<?php else: echo ($vo["starpicurl"]); endif; ?>" width="373px" >	
		<br />
		<input class="px"  name="starpicurl" value="<?php if($vo['starpicurl'] == ''): echo C('site_url');?>/tpl/User/default/common/images/img/zajindanstart1.jpg<?php else: echo ($vo["starpicurl"]); endif; ?>"   onclick="document.getElementById('pic').src=this.value;" style="width:363px;"  />
		<br /><input name="type" value="4" type="hidden"   />
		填写活动开始图片网址
	  </div>
  </TD>
</TR>
<TR>
  <th valign="top"><span class="red">*</span>活动名称：</th>
  <TD>
	<input type="input" class="px" id="title" value="<?php if($vo['title'] == ''): ?>砸金蛋活动开始了<?php else: echo ($vo["title"]); endif; ?>" name="title" style="width:400px" />
  	<br />
  	请不要多于50字!
  </TD>
  <TR>
  	<th valign="top"><span class="red">*</span>兑奖信息：</th>
  	<td>
		<input type="input" class="px" id="txt" value="<?php if($vo['txt'] == ''): ?>兑奖请联系我们，电话18950099999<?php else: echo ($vo["txt"]); endif; ?>" name="txt" style="width:400px" />
  		<br />请不要多于100字! 这个设定但用户输入兑奖时候的显示信息!
	</td>
  </TR>
 <TR>
  	<th valign="top"><span class="red">*</span>中奖提示：</th>
  	<td><textarea class="px"   name="sttxt" style="width:400px"  ><?php echo ($vo["sttxt"]); ?></textarea>
  		 </td>
</TR>
<TR>
	<th><span class="red">*</span>活动时间：</th>
	<td><input type="input" class="px" id="statdate" value="<?php if($vo['statdate'] != ''): echo (date("Y-m-d H:i:s",$vo["statdate"])); else: echo date('Y-m-d H:i:s',mktime(0, 0, 0, date("m") , date("d"), date("Y"))); endif; ?>" onClick="WdatePicker()" name="statdate" />                
		到
		<input type="input" class="px" id="enddate" value="<?php if($vo['enddate'] != ''): echo (date("Y-m-d H:i:s",$vo["enddate"])); else: echo date('Y-m-d H:i:s',mktime(0, 0, 0, date("m") , date("d")+3, date("Y"))); endif; ?>" name="enddate" onClick="WdatePicker()"  /> 
	</td>
</TR>
<TR>
<th valign="top">活动说明：</th>
<td><textarea  class="px" id="info" name="info"  style="width:400px; height:125px" ><?php if($vo['info'] == ''): ?>亲，请点击进入砸金蛋抽奖活动页面，祝您好运哦！<?php else: echo ($vo["info"]); endif; ?></textarea><br />换行请输入
 &lt;br&gt;
 </td>
</TR>
</TBODY>
</TABLE>
  </div> 
  
<!--活动结束-->
<div class="cLineB">
          	<h4>活动结束内容</h4></div> 
<div class="msgWrap bgfc">
 
  	<table class="userinfoArea" style=" margin: 0;" border="0" cellspacing="0" cellpadding="0" width="100%">
  		<tbody>
  			<tr>
  				<th valign="top"><span class="red">*</span>活动结束公告主题：</th>
  				<td><input type="input" class="px" id="endtite" value="<?php if($vo['endtite'] == ''): ?>砸金蛋活动已经结束了<?php else: echo ($vo["endtite"]); endif; ?>" name="endtite" style="width:400px" />
  					<br />
  					请不要多于50字! </td>
  				<td rowspan="4" valign="top"><div style="margin-left:20px"><img  id="end" src="<?php if($vo['endpicurl'] == ''): echo C('site_url');?>/tpl/User/default/common/images/img/zajindanend1.jpg<?php else: echo ($vo["endpicurl"]); endif; ?>"  width="373px"/> <br />
  					<input class="px"  name="endpicurl" value="<?php if($vo['endpicurl'] == ''): echo C('site_url');?>/tpl/User/default/common/images/img//zajindanend1.jpg.jpg<?php else: echo ($vo["endpicurl"]); endif; ?>"  onchange="document.getElementById('end').src=this.value;"  style="width:363px;"  />
  					<br />
  					填写活动结束图片网址 </div></td>
  				</tr>
  			<tr>
  				<th valign="top">活动结束说明：</th>
  				<td valign="top"><textarea  class="px" id="endinfo" name="endinfo"  style="width:400px; height:125px" ><?php if($vo['endinfo'] == ''): ?>亲，活动已经结束，请继续关注我们的后续活动哦。<?php else: echo ($vo["endinfo"]); endif; ?></textarea><br />换行请输入
 &lt;br&gt;
  				  </td>
  				</tr>
  			</tbody>
  		</table>
  </div> 
  
  
<!--奖项设置-->
<div class="cLineB">
          	<h4>奖项设置</h4></div> 
<div class="msgWrap bgfc">

<TABLE class="userinfoArea" style=" margin: 0;" border="0" cellSpacing="0" cellPadding="0" width="100%">
<TBODY>
<TR>
<th valign="top"><span class="red">*</span>一等奖奖品设置：</th>
<td><input type="input" class="px" id="fist"   name="fist" value="<?php echo ($vo["fist"]); ?>"  style="width:250px"/>
请不要多于50字! </td>
  <TD rowspan="9" valign="top">&nbsp;</TD>
</TR>
<TR>
<th valign="top"><span class="red">*</span>一等奖奖品数量：</th>
<td><input type="input" class="px" id="fistnums" name="fistnums"      value="<?php echo ($vo["fistnums"]); ?>" style="width:60px" />
  <span class="red">如果是100%中奖,请把一等奖的奖品数量[ 1000就代表前1000人都中奖 ]填写多点</span></td>
                                      </TR>
<TR>
<th valign="top">二等奖奖品设置：</th>
<td><input type="input" class="px" id="second" name="second"     value="<?php echo ($vo["second"]); ?>"  style="width:250px"/>
请不要多于50字! </td>
                                          </TR>
<TR>
<th valign="top">二等奖奖品数量：</th>
<td><input type="input" class="px" id="secondnums" name="secondnums"   value="<?php echo ($vo["secondnums"]); ?>" style="width:60px" />
</td>
                                          </TR>
<TR>
<th valign="top">三等奖奖品设置：</th>
<td><input type="input" class="px" id="third" name="third"   value="<?php echo ($vo["third"]); ?>" style="width:250px" />
请不要多于50字! </td>
                                        
                                          </TR>
<TR>
<th valign="top">三等奖奖品数量：</th>
<td><input type="input" class="px" id="thirdnums" name="thirdnums"     value="<?php echo ($vo["thirdnums"]); ?>" style="width:60px" />
</td>
                                       
                                          </TR>
  
  </tbody>
 <tbody>
<TR>
<th valign="top"><span class="red">*</span>预计活动的人数：</th>
<td><input type="input" class="px" id="allpeople" name="allpeople"   value="<?php echo ($vo["allpeople"]); ?>" style="width:150px"/>  预估活动人数直接影响抽奖概率：中奖概率 = 奖品总数/(预估活动人数*每人抽奖次数) 如果要确保任何时候都100%中奖建议设置为1人参加!<span class='red'>如果要确保任何时候都100%中奖建议设置为1人参加!并且奖项只设置一等奖.</span></td>
  </TR>
                                <TR>
<th valign="top"><span class="red">*</span>每人最多允许抽奖次数：</th>
<td><input type="input" class="px" id="canrqnums" name="canrqnums"   value="<?php echo ($vo["canrqnums"]); ?>" style="width:150px"/>
必须1-5之间的数字</td>
 </TR>

<TR>
	<th valign="top">抽奖页面是否显示奖品数量：</th>
	<td><input class="radio" type="radio" name="displayjpnums" value="1"  <?php if($vo['displayjpnums'] == 1): ?>checked<?php endif; ?> >显示  <input class="radio" type="radio" name="displayjpnums" value="0"  <?php if($vo['displayjpnums'] == 0): ?>checked<?php endif; ?>>不显</td> 
</TR> 
<TR>
<th>&nbsp;</th>
<td><button type="submit" class="btn btn-primary" >保存</button>　<a href=""  class="btn btn-primary">取消</a>　<span class="red">请确认功能管理已开启砸金蛋功能</span></td>
</TBODY>
</TABLE>
  </div> 
 </div>
</form>
        <div class="clr"></div>
      </div>
    </div>
  </div> 
  <script type="text/javascript">
	//onFocus事件就是当光标落在文本框中时发生的事件。
	//onBlur事件是光标失去焦点时发生的事件。
	function onfocus(obj){
		obj.html = '';
	}
	function onblur(obj,str){
		obj.html = str;
	}
  </script>
<!--底部-->
</div>
﻿</div>
</div>
</div>

<style>
.IndexFoot {
	BACKGROUND-COLOR: #ff4400; WIDTH: 100%; HEIGHT: 39px
}
.foot{ width:988px; margin:0px auto; font-size:12px; line-height:39px;}
.foot .foot_page{ float:left; width:600px;color:white;}
.foot .foot_page a{ color:white; text-decoration:none;}
#copyright{ float:right; width:380px; text-align:right; font-size:12px; color:#FFF;}
</style>
<div class="IndexFoot" style="height:120px;clear:both">
<div class="foot">
<div class="foot_page" >
<a href="<?php echo C('site_url');?>">微酷cms微信公众平台营销</a><br/>
帮助您快速搭建属于自己的营销平台,构建自己的客户群体。<br/>
大转盘、刮刮卡，会员卡,优惠卷,订餐,订房等营销模块,客户易用,易懂,易营销（微酷cms-3易服务理念）。
</div>
<div id="copyright" style="color:white">
	<?php echo C('site_name');?>(c)2013 微酷cms版权所有<br/>
	技术支持：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=2892491366&site=qq&menu=yes"><img height="20" border="0" src="http://wpa.qq.com/pa?p=2:2892491366:51" alt="联系我吧" title="联系我吧"/></a>
	售前咨询：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=2892491366&site=qq&menu=yes"><img height="20" src="http://wpa.qq.com/pa?p=2:2892491366:51" alt="联系我吧" title="联系我吧"/></a>

</div>
  </div>
</div>

</body>
</html>