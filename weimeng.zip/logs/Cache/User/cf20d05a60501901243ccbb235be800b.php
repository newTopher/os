<?php if (!defined('THINK_PATH')) exit();?><center><?php echo ($info); ?>
</center>