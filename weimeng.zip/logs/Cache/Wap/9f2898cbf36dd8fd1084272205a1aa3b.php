<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<link href="<?php echo RES;?>/css/Estate/lp/css/style.css" rel="stylesheet" type="text/css" media="all" />
<script src="<?php echo RES;?>/css/Estate/lp/js/share.js" type="text/javascript"></script>
<!--控制展开合并-->
<script src="<?php echo RES;?>/css/Estate/lp/js/common.js" type="text/javascript"></script>
<!--控制弹出无效户型-->
<script src="<?php echo RES;?>/css/Estate/lp/js/house.js" type="text/javascript"></script>
<!--控制展开合并-->
<title>楼盘</title>
<meta content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
<!-- Mobile Devices Support @begin -->
<meta content="no-cache,must-revalidate" http-equiv="Cache-Control">
<meta content="no-cache" http-equiv="pragma">
<meta content="0" http-equiv="expires">
<meta content="telephone=no, address=no" name="format-detection">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta name="apple-mobile-web-app-capable" content="yes">
<!-- apple devices fullscreen -->
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<!-- Mobile Devices Support @end -->
<link rel="shortcut icon" href="<?php echo RES;?>/css/Estate/img/favicon.ico" />
</head>
<body onselectstart="return true;" ondragstart="return false;">
<div class="wrapper" id="container">
  <!--底部浮动按钮 开始-->
  <footer class="nav_footer">
    <ul class="box_db">
      <li><a href="javascript:history.go(-1);">返回</a></li>
      <li><a href="javascript:history.go(1);">前进</a></li>
      <li><a href="<?php echo U('Estate/Estate_index',array('token'=>$_GET['token'],'id'=>$estate['id']));?>">首页</a></li>
      <li><a href="javascript:location.reload();">刷新</a></li>
    </ul>
  </footer>
  <!--底部浮动按钮 结束-->
  <!-- start -->
  <div class="act_top" id="actTop">
    <div class="act_top_show"> <img src="<?php echo ($info["toppicurl"]); ?>" width="100%" height="150"  id="bannerPic"> </div>
  </div>
  <div class="box">
    <h3>楼盘</h3>
    <div class="box_type" style=" height:auto;">
      <ul class="house_type_lp">
        <!-- 默认展开<li id="boxLi27" class="current"> <a href="javascript:void(0);" onClick="List.toggleList(27,0);"> <strong><?php echo ($info["name"]); ?></strong> <span><?php echo ($info["sub"]); ?></span> <em><?php echo ($info["lc"]); ?>层&nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($info["shi"]); ?>室<?php echo ($info["ting"]); ?>厅&nbsp;&nbsp;&nbsp;&nbsp;约<?php echo ($info["area"]); ?>平方米</em> </a>
            <div class="house_photo house_arrow"> <a href="javascript:void(0);" onClick="List.showDetail(27);return false;" class="ico_type">户型图</a> <a href="javascript:void(0);" onClick="List.show3D(27);return false;" class="ico_360">全景图</a> </div>
          </li>
		  -->
        <?php if(is_array($lp)): $i = 0; $__LIST__ = $lp;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$info): $mod = ($i % 2 );++$i;?><li id="boxLi29"> <a href="<?php echo U('Estate/index',array('token'=>$_GET['token'],'id'=>$info['id']));?>" onClick="List.toggleList(29,0);"><span><?php echo ($info["title"]); ?></span> </a>
            <!-- <div class="house_photo" style="display:none;"> <a href="<?php echo U('Estate/elist',array('token'=>$_GET['token'],'id'=>$info['id']));?>"  class="ico_type">户型图</a> <a href="javascript:void(0);" onClick="List.show3D(0);return false;" class="ico_360">全景图</a> </div>-->
          </li><?php endforeach; endif; else: echo "" ;endif; ?>
      </ul>
    </div>
  </div>
  <!-- end -->
  <!--滑动菜单开始
  <include file="Estate:include"
 滑动菜单结束-->
</div>
<div id="popFail" style="display: none; " jqmoldstyle="block">
  <div class="bk"></div>
  <div class="cont"> <img src="<?php echo RES;?>/css/Estate/jianjie/img/img.gif" alt="loading..."> 正在加载... </div>
</div>
</body>
</html>